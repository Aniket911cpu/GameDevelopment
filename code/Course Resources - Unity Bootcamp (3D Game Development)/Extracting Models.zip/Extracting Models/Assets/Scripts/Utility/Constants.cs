namespace RPG.Utility
{
    public static class Constants
    {
        public const string PLAYER_TAG = "Player";
    }
}