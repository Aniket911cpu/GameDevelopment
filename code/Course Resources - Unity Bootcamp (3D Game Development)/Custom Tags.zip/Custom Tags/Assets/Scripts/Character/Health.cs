using System;
using UnityEngine;

namespace RPG.Character
{
    public class Health : MonoBehaviour
    {
        [NonSerialized] public float healthPoints = 0f;
    }
}