namespace RPG.Character
{
    public enum Weapons
    {
        Axe,
        Sword
    }
}